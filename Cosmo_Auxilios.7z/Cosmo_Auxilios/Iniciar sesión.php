<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

            <!-- Core theme CSS (includes Bootstrap)-->
            <link href="Styles/styles.css" rel="stylesheet" />

  <link rel="stylesheet" href="Styles/stilos.css">
  <title>Iniciar sesión</title>
  <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
</head>
<body>
  
  <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
    <div class="container px-5">
        <a class="navbar-brand" href="index.html">Auxilios Cosmo</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ms-auto">
            </ul>
        </div>
        <div>
            <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <li class="nav-item"><a class="nav-link" href="#1">INICIAR SESION</a></li> 
                        <li class="nav-item"><a class="nav-link" href="formulario.php">REGISTRARSE</a></li>                
                      </li>
                    <li class="nav-item">
                    </li>
                </div>
        </nav>
        </div>
    </div>
</nav>
  <section class="form-register">
    <h4>Iniciar Sesion</h4>
    <input class="controls" type="email" name="correo" id="correo" placeholder="Ingrese su Correo">
    <input class="controls" type="password" name="correo" id="correo" placeholder="Ingrese su contraseña">
  </form>
    

    <p>Estoy de acuerdo con <a href="Terminos y condiciones.html">Terminos y Condiciones</a></p>
    <p><a href="Bienvenido.html">Iniciar sesión</a></p>
    <p><a href="#">¿Ya tengo Cuenta?</a></p>
  </section>

</body>
</html>