$('#btn_guardar').click(function(){
    Swal.fire(
    'Exito!',
    'Se guardo de la manera correcta',
    'success'
    )
});