    <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

            <!-- Core theme CSS (includes Bootstrap)-->
            <link href="css/styles.css  " rel="stylesheet" />

  <link rel="stylesheet" href="css/stilos.css">
  <title>Iniciar sesión</title>
  <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
</head>
<body>
  
  <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
    <div class="container px-5">
        <a class="navbar-brand" href="index.html">Auxilios Cosmo</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ms-auto">
                <a class="nav-link active" aria-current="page" href="index.html">INICIO</a>
            </ul>
        </div>
        <div>
            <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <li class="nav-item"><a class="nav-link" href="Iniciar sesión.html">INICIAR SESION</a></li> 
                        <li class="nav-item"><a class="nav-link" href="formulario.php">REGISTRARSE</a></li>                
                      </li>
                    <li class="nav-item">
                    </li>
                </div>
        </nav>
        </div>
    </div>
</nav>
    <center>
    <h1>Términos y condiciones</h1>
    <p>Por favor, lea atentamente los siguientes términos y condiciones antes de utilizar nuestro servicio.</p>
    <br>
    <br>
    <h2>Uso del servicio</h2>
    <p>Al utilizar nuestro servicio, usted acepta cumplir con estos términos y condiciones y cualquier política o directriz que se le proporcione.</p>
    <br>
    <br>
    <h2>Propiedad intelectual</h2>
    <p>Todos los derechos de propiedad intelectual relacionados con nuestro servicio son propiedad exclusiva de nuestra empresa.</p>
    <br>
    <br>
    <h2>Limitación de responsabilidad</h2>
    <p>No seremos responsables por ningún daño directo o indirecto resultante del uso o imposibilidad de uso de nuestro servicio.</p>
    <br>
    <br>
    <h2>Modificaciones</h2>
    <p>Nos reservamos el derecho de modificar estos términos y condiciones en cualquier momento. Los cambios entrarán en vigencia inmediatamente después de su publicación en nuestro sitio web.</p>
    <br>
    <br>
    <h2>Acuerdo completo</h2>
    <p>Estos términos y condiciones representan el acuerdo completo entre usted y nuestra empresa en relación con el uso de nuestro servicio.</p>
    <br>
    <br>
    <h2>Contacto</h2>
    <p>Si tiene alguna pregunta o comentario sobre estos términos y condiciones, por favor contáctenos a través de nuestro sitio web.</p>
    <br>
    <br>

</center>
  </body>
</html>